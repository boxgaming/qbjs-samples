Import Dom From "lib/web/dom.bas"
Import G2D From "lib/2d.bas"

$if javascript then
    // HTML5 canvas out-of-focus fix
    /*
    window.setTimeout(() => {
      "use strict";

      const canvas = document.getElementById("gx-canvas")
      canvas.addEventListener("click", () => {
        canvas.tabIndex = 0
        canvas.focus()
      })
    }, 1000)*/
    
    try { resizeScreen(); } catch (e) { console.log(e); }
$endif
dim shared fpress
fpress = GX_FALSE


dim shared health
health = 100

dim shared checkpoint 
checkpoint = 0 


type particletype
    x as long   
    y as long   
    
    vx as long   
    vy as long   
    
    c as long
end type

dim shared blood(50) as particletype
dim shared blood_t
blood_t = 0

dim shared smoke(50) as particletype
dim shared smoke_t
smoke_t = 0

dim shared eblood(50) as particletype
dim shared eblood_t
eblood_t = 0

dim shared esmoke(50) as particletype
dim shared esmoke_t
esmoke_t = 0

dim shared rocket as particletype
dim shared rocket_t
dim shared rocket_shot, rocket_hit, rocket_period 'state
rocket_t = 0
rocket_shot = 0
rocket_hit = 0
rocket_period = 0



type weapontype
    img as long
    typ as long
    avail as long
    
    range as long
    recoil as long
    period as long
    
    damage as long
end type
dim shared weapon(4) as weapontype
dim shared aw 'active weapon
aw = 2

weapon(0).img = loadimage("img/swordx1.png")
weapon(0).typ = 0
weapon(0).avail = 0
weapon(0).range = 42
weapon(0).recoil = 0
weapon(0).period = 10
weapon(0).damage = 350


weapon(1).img = loadimage("img/riflex2.png")
weapon(1).typ = 0
weapon(1).avail = 0
weapon(1).range = 500
weapon(1).recoil = 45
weapon(1).period = 7
weapon(1).damage = 25

weapon(2).img = loadimage("img/launcher.png")
weapon(2).typ = 0
weapon(2).avail = 1
weapon(2).range = 1400
weapon(2).recoil = 0
weapon(2).period = 5
weapon(2).damage = 350


' create vehicles
type vehicletype
    entity as long
    accel as long
    max_accel as long
    
    health as long
end type
dim shared vehicle(4) as vehicletype
dim shared av 'active vehicle

dim shared helicopter
helicopter = GXEntityCreate("img/helix3x.png", 146, 54, 4)
GXEntityPos helicopter, 3438, 3486
GXEntityCollisionOffset helicopter, 3, 5, 3, 0
GXEntityApplyGravity helicopter, GX_TRUE

av = 0
vehicle(0).entity = helicopter
vehicle(0).accel = 20
vehicle(0).max_accel = 300

'barrels
dim shared global_msg
global_msg = ""


dim shared shot, hit, shot_time
dim shared hit_x, hit_y
shot_time = 0
shot = 0
hit = -1



dim shared laser
laser = 0



dim shared pilot, hold_e
hold_e = 0
pilot = 0

dim shared hold_q
hold_q = 0


Const ACCEL = 10
Const MAX_ACCEL = 200
Const MOVE_RIGHT = 1
Const MOVE_LEFT = 2
Dim Shared direction As Integer
Dim Shared edirection As Integer
Dim Shared jumping As Integer
Dim Shared gameOver As Integer
direction = MOVE_RIGHT


const SCALE = 2
dim shared sw, sh
sw = resizewidth
sh = resizeheight

Dim As Object canvas, container
canvas = Dom.GetImage(0)
canvas.style.border = "0"
canvas.style.margin = "0"
container = Dom.Container
container.style.overflow = "hidden"

GXSceneCreate sw/SCALE, sh/SCALE
GXSceneScale SCALE

'GXFullScreen GX_TRUE
'If Resize Then
'  GXSceneWindowSize ResizeWidth/SCALE-5, ResizeHeight/SCALE-5
'End If


' Create the backgrounds
Dim As Long bg1, bg2
bg2 = GXBackgroundAdd("img/BG.png", GXBG_STRETCH)
bg1 = GXBackgroundAdd("img/clouds2.png", GXBG_WRAP)
'bg2 = GXBackgroundAdd("img/mountains.png", GXBG_WRAP)
GXBackgroundWrapFactor bg1, .25


' Create the map
'GXMapLoad "map/newmap.gxm"
'GXMapLoad "map/test.gxm"
GXMapLoad "map/northpole.gxm"

Const COLLISION_LAYER = 1
Const COLLISION_LAYER2 = 4
Const COLLISION_TILE = 16
GXMapLayerVisible COLLISION_LAYER2, GX_FALSE




type enemytype
    entity as long
    typ as long
    health as long
    radius as long
    period as long
end type

redim shared enemy(100) as enemytype


LoadEnemies




'''''''''''''''' Create the player
Dim Shared player As Long
player = GXEntityCreate("img/santa.png", 24, 24, 4)





respawn







'GXEntityPos player, 2071, 3086 'rice
'GXEntityPos player, 1284, 3980 'oasis

'GXEntityPos player, 6396, 2552 'tower2
'GXEntityPos helicopter, 6300, 2500

'GXEntityPos player, 8812, 3506 'castle


GXEntityCollisionOffset player, 6, 5, 6, 0
GXEntityApplyGravity player, GX_TRUE
    
GXSceneFollowEntity player, GXSCENE_FOLLOW_ENTITY_CENTER 


'enemy fire tracer
dim shared lx, ly, lx1, ly1
lx = 0
ly = 0
lx1 = 10
ly1 = 10





'reflector cylinders

type reflectortype
    entity as long
    
    x as long
    y as long
    r as long

end type
dim shared reflector(100) as reflectortype


LoadMirrors




dim shared box(12)
box( 0) = 1
box( 1) = 1
box( 2) = 1
box( 3) = 1
box( 4) = 1
box( 5) = 1
box( 6) = 1
box( 7) = 1
box( 8) = 1
box( 9) = 1
box(10) = 1
box(11) = 1
box(12) = 1


dim shared crate(19)
crate( 0) = 1
crate( 1) = 1
crate( 2) = 1
crate( 3) = 1
crate( 4) = 1
crate( 5) = 1
crate( 6) = 1
crate( 7) = 1
crate( 8) = 1
crate( 9) = 1
crate(10) = 1
crate(11) = 1
crate(12) = 1
crate(13) = 1
crate(14) = 1
crate(15) = 1
crate(16) = 1
crate(17) = 1
crate(18) = 1
crate(19) = 1

' Start handling game events
GXSceneConstrain GXSCENE_CONSTRAIN_TO_MAP
GXSceneStart




Sub GXOnGameEvent (e As GXEvent)
    Select Case e.event
        Case GXEVENT_UPDATE: OnUpdate e
        Case GXEVENT_DRAWSCREEN: OnDrawScreen e
        Case GXEVENT_COLLISION_TILE: OnTileCollision e
    End Select
    
    'limit 60
End Sub

Sub OnTileCollision(e As GXEvent)
    If GXMapTile(e.collisionTileX, e.collisionTileY, COLLISION_LAYER) Then
        e.collisionResult = GX_TRUE
    
    elseIf GXMapTile(e.collisionTileX, e.collisionTileY, COLLISION_LAYER2) = COLLISION_TILE Then
        If GXEntityY(e.entity) + GXEntityHeight(e.entity) - 8 < e.collisionTileY * GXTilesetHeight + 1 Then
            e.collisionResult = GX_TRUE
        End If
        
    End If
End Sub


Sub OnUpdate (e As GXEvent)
    If Resize Then GXSceneWindowSize ResizeWidth, ResizeHeight

    HandlePlayerMovement
    
    HandleEnemyMovement
    

    if health <= 0 then
        gameOver = GX_TRUE
    end if
    
    if GXKeyDown(GXKEY_ESC) then
        gameOver = GX_TRUE
    end if
    
    'fall death
    if int(GXEntityY(player)/GXTilesetHeight) >= 300 then
        gameOver = GX_TRUE
    end if
    
    If gameOver Then
        'GXEntityVisible player, GX_TRUE
        '
        
        
        GXSceneStop
        delay 1
        
        
        gameOver = GX_FALSE
        
        respawn
        
        GXSceneStart
        
        
        'end
    end if
    
End Sub

Sub HandlePlayerMovement
    
    if GXKeyDown(GXKEY_Q) and hold_q = 0 then
        hold_q = 1
        
        aw = abs((aw + 1) mod 5)
        do while weapon(aw).avail = 0 
            aw = abs((aw + 1) mod 5)    
        loop
    elseif (not GXKeyDown(GXKEY_Q)) and hold_q = 1 then
        hold_q = 0
    
    end if
    
    
'enter vehicle
    If GXKeyDown(GXKEY_E) and hold_e = 0  Then
        hold_e = 1
        
        if pilot = 0 then
        
            collided = 0
            for i=0 to ubound(vehicle)
                if GXEntityCollide(player, vehicle(i).entity) then
                    collided = 1
                    av = i
                    exit for
                end if
            next
        
            'if GXEntityCollide(player, helicopter) then
            if collided then
                pilot = 1

                vx = 0
                vy = 0 
                GXEntityVX player, vx
                GXEntityVY player, vy

                GXSceneFollowEntity vehicle(av).entity, GXSCENE_FOLLOW_ENTITY_CENTER '_X
                
                GXEntityApplyGravity vehicle(av).entity, GX_FALSE
                'GXEntityApplyGravity player, GX_FALSE

                GXEntityVisible player, GX_FALSE
                
            GXEntityAnimate vehicle(av).entity, direction+2, 15
                
                collided = 0
            end if
'exit vehicle            
        else
            pilot = 0
            
            GXEntityVX vehicle(av).entity, 0
            GXEntityVY vehicle(av).entity, 0
            GXEntityApplyGravity vehicle(av).entity, GX_TRUE
            
            GXEntityPos player, GXEntityX(vehicle(av).entity) , GXEntityY(vehicle(av).entity)
 
            GXSceneFollowEntity player, GXSCENE_FOLLOW_ENTITY_CENTER '_X
            GXEntityVisible player, GX_TRUE
            
        GXEntityAnimate vehicle(av).entity, direction, 15
            GXEntityAnimateStop vehicle(av).entity
            
        end if
    elseif not GXKeyDOWN(GXKEY_E) and hold_e = 1 then
        hold_e = 0 
    end if


'player movement
    if pilot = 0 then
        vx = GXEntityVX(player)
        vy = GXEntityVY(player)

        ' move right
        If GXKeyDown(GXKEY_D) Or GXKeyDown(GXKEY_RIGHT) Then
            vx = vx + ACCEL
            If vx > MAX_ACCEL Then vx = MAX_ACCEL
            direction = MOVE_RIGHT
            GXEntityAnimate player, direction, 15

        ' move left
        ElseIf GXKeyDown(GXKEY_A) Or GXKeyDown(GXKEY_LEFT) Then
            vx = vx - ACCEL
            If vx < MAX_ACCEL * -1 Then vx = MAX_ACCEL * -1
            direction = MOVE_LEFT
            GXEntityAnimate player, direction, 15

        ' slow down when a direction key is not pressed
        ElseIf vx > 0 Then
            vx = vx - ACCEL
            If vx < 0 Then vx = 0

        ElseIf vx < 0 Then
            vx = vx + ACCEL
            If vx > 0 Then vx = 0

        Else
            GXEntityAnimateStop player
        End If

        'jump
        If vy = 0 And (GXKeyDown(GXKEY_K) Or GXKeyDown(GXKEY_W) or GXKeyDown(GXKEY_SPACEBAR)) Then
            GXEntityVY player, -260
        End If

        ' idle
        If vy = 0 And vx = 0 Then
            if pilot then
                GXEntityAnimateStop helicopter
                GXEntityFrameSet helicopter, direction+2, 1
            else
                GXEntityAnimateStop player
                GXEntityFrameSet player, direction, 1
            end if

        End If

        GXEntityVX player, vx

        ' fall faster for a less "floaty" jump

        If vy > 0 Then
            GXEntityVY player, vy + 25
        ElseIf vy < 0 Then
            GXEntityVY player, vy + 10
        end if    
        
  '''''inside vehicle -- ignore player stuff
  else 'helicopter movement
        'GXEntityFrameSet vehicle(av).entity, direction, 4
            
        vx = GXEntityVX(vehicle(av).entity)
        vy = GXEntityVY(vehicle(av).entity)

        key = 0
        

        ' move right
        If GXKeyDown(GXKEY_D) Or GXKeyDown(GXKEY_RIGHT) Then
            vx = vx + vehicle(av).accel
            If vx > vehicle(av).max_accel Then vx = vehicle(av).max_accel
            direction = MOVE_RIGHT
            GXEntityAnimate vehicle(av).entity, direction+2, 15
            key = 1

        ' move left
        ElseIf GXKeyDown(GXKEY_A) Or GXKeyDown(GXKEY_LEFT) Then
            vx = vx - vehicle(av).accel
            If vx < vehicle(av).max_accel * -1 Then vx = vehicle(av).max_accel * -1
            direction = MOVE_LEFT
            GXEntityAnimate vehicle(av).entity, direction+2, 15
            key = 1

        Else
            'GXEntityAnimateStop vehicle(av).entity
            'GXEntityAnimate vehicle(av).entity, direction, 15
        End If

        'move up & down
        if GXKeyDown(GXKEY_S) then
            vy = vy + vehicle(av).accel
            If vy > vehicle(av).max_accel Then vy = vehicle(av).max_accel
            GXEntityAnimate vehicle(av).entity, direction+2, 15
            key = 1

        elseif GXKeyDown(GXKEY_W) then
            vy = vy - vehicle(av).accel
            If vy < vehicle(av).max_accel * -1 Then vy = vehicle(av).max_accel * -1
            GXEntityAnimate vehicle(av).entity, direction+2, 15
            key = 1

        Else
            'GXEntityAnimateStop vehicle(av).entity
            'GXEntityAnimate vehicle(av).entity, direction, 15
        End If
        
        'GXEntityAnimate vehicle(av).entity, direction+2, 15

        if key = 0
            If vx > 0 Then
                vx = vx - vehicle(av).accel
                If vx < 0 Then vx = 0
            end if
            If vx < 0 Then
                vx = vx + vehicle(av).accel
                If vx > 0 Then vx = 0
            end if
            If vy > 0 Then
                vy = vy - vehicle(av).accel
                If vy < 0 Then vx = 0
            end if
            If vy < 0 Then
                vy = vy + vehicle(av).accel
                If vy > 0 Then vx = 0
            end if
        end if


        ' idle
        'If vy = 0 And vx = 0 Then
            'GXEntityAnimateStop vehicle(av).entity
            'GXEntityFrameSet vehicle(av).entity, direction, 1
        'End If


        GXEntityVX vehicle(av).entity, vx
        GXEntityVY vehicle(av).entity, vy

    
    end if


'''''''''''''''''''''''''''''''''
''''''''''''gun controls'''''''''
'''''''''''''''''''''''''''''''''
if pilot = 0  then

    '''switch weapons
    if mousewheel <> 0 then
        aw = abs((aw + 1) mod 5)    
        do while weapon(aw).avail = 0 
            aw = abs((aw + 1) mod 5)    
        loop 
    end if
    
    
    'fire gun
    if mousebutton(1) then
    
        if aw = 2 then
            laser = 1
        else
            if shot_time = 0 then
                shot = 1
                shot_time = weapon(aw).period
            end if
        end if
        
    elseif mousebutton(1) = 0 then
    
        if laser = 1 then laser = 0
    
        shot_time = 0
    end if
    
    
    
    
if aw = 2 then 'laser

    
   'if laser = 1 then
   '
   '
   'end if
    
else
    'fire gun state
    if shot = 1 then
        x0 = 12 + GXEntityX(player) - GXSceneX
        y0 = 14 + GXEntityY(player) - GXSceneY
        
        a = atan2( mousey - y0, mousex - x0 )

        x = 12 + GXEntityX(player) 
        y = 14 + GXEntityY(player) 
        
    'recoil
        GXEntityVX player, -weapon(aw).recoil*cos(a)
        GXEntityVY player, -weapon(aw).recoil*sin(a)
        
    'make gunfire particles
        select case aw
        case 1 'machinegun
            smoke_t = 8
            for i=0 to ubound(smoke)
                smoke(i).x = x + 35*cos(a - 0.5*rnd)
                smoke(i).y = y + 35*sin(a - 0.5*rnd)
                smoke(i).vx = cos(a)
                smoke(i).vy = sin(a)
            next
        'case 2 
        '    smoke_t = 8
        '    for i=0 to ubound(smoke)
        '        smoke(i).x = x + 23*cos(a - 0.5*rnd)
        '        smoke(i).y = y + 23*sin(a - 0.5*rnd + 0.35) 
        '        smoke(i).vx = cos(a)
        '        smoke(i).vy = sin(a)
        '    next
        end select
        
        '''gun fire collisions
        hit = -1
        for t=0 to weapon(aw).range step 1
            x = x + cos(a)
            y = y + sin(a)
            
            tx = Fix((x)/GXTilesetWidth)
            ty = Fix((y)/GXTilesetHeight)
            tile = GXMapTile(tx, ty, COLLISION_LAYER) 'layer=1
            
            if tile <> 0 then exit for
                
            for i=0 to ubound(enemy)
                ex = GXEntityX(enemy(i).entity)
                ey = GXEntityY(enemy(i).entity)
                if x > ex and x < ex + GXEntityWidth(enemy(i).entity) then
                if y > ey and y < ey + GXEntityHeight(enemy(i).entity) then
                    hit_x = x
                    hit_y = y
                    hit = i
           enemy(hit).health = enemy(hit).health - weapon(aw).damage
                    exit sub
                end if
                end if
            next
        next
    
    end if
end if
    
''''''''''''''''''
''''obtain items''
''''''''''''''''''
    tx = Fix(GXEntityX(player)/GXTilesetWidth)
    ty = Fix(GXEntityY(player)/GXTilesetHeight)
    
    'if item( 0) and ty = 174 and (tx>=30 and tx<=31) then
    '    item( 0) = 0
    '    if health < 100 then health = 100
    '    aw = 3
    '    weapon(3).avail = weapon(3).avail + 10
    'end if


    if tx=227 and ty=169 then 'sword
        if crate(0) then
            weapon(0).avail = 1
            aw = 0
            crate(0) = 0
        end if
    
    elseif (tx=229 or tx=230) and ty = 155 then 'check
        if crate(1) then
            checkpoint = 1
            crate(1) = 0
        end if
    
    
    elseif tx=273 and ty=175 then 'm
        if crate(2) then
            health = health + 5
            crate(2) = 0
        end if
    
    
    elseif tx=396 and ty=159 then 'ak
        if crate(3) then
            weapon(1).avail = 1
            aw = 1
            crate(3) = 0
        end if
    
    
    elseif (tx=398 or tx=399) and ty=160 then 'check
        if crate(4) then
            checkpoint = 2
            crate(4) = 0
        end if
    
    
    elseif tx=442 and ty=204 then 'm
        if crate(5) then
            health = health + 5
            crate(5) = 0
        end if
    
    
    elseif (tx=286 or tx=287) and ty=214 then 'health2
        if crate(6) then
            health = health + 50
            crate(6) = 0
        end if
    
    
    elseif (tx=290 or tx=291 or tx=292) and ty=214 then 'ak
        if crate(7) then
            weapon(1).avail = 1
            aw = 1
            crate(7) = 0
        end if
    

    elseif tx=295 and ty=214 then 'm
        if crate(8) then
            health = health + 5
            crate(8) = 0
        end if
    
    
    elseif tx=306 and ty=220 then 'health
        if crate(9) then
            health = health + 25
            crate(9) = 0
        end if
    
    elseif tx=308 and ty=225 then 'health
        if crate(10) then
            health = health + 25
            crate(10) = 0
        end if
    
    elseif (tx=279 or tx=280) and ty=229 then 'health2
        if crate(11) then
            health = health + 50
            crate(11) = 0
        end if
    
    
    elseif tx=74 and ty=250 then 'm
        if crate(12) then
            health = health + 5
            crate(12) = 0
        end if
    
    
    elseif tx=27 and ty=250 then 'm
        if crate(13) then
            health = health + 5
            crate(13) = 0
        end if
    
    
    elseif tx=36 and ty=254 then 'health
        if crate(14) then
            health = health + 25
            crate(14) = 0
        end if
    
    
    elseif tx=39 and ty=254 then 'health
        if crate(15) then
            health = health + 25
            crate(15) = 0
        end if
    
    
    elseif tx=100 and ty=187 then 'health
        if crate(16) then
            health = health + 25
            crate(16) = 0
        end if


'elves

    elseif (tx=231 or tx=232) and ty=167 then 'tower1
        if crate(17) then
            crate(17) = 0
            
            
          for k=0 to 2
              i=ubound(enemy)+1
                redim preserve enemy(i)
              enemy(i).typ = 2
              enemy(i).entity = GXEntityCreate("img/elf.png", 16, 16, 4)
              GXEntityPos enemy(i).entity, 3734 + int(20*k), 2682
              GXEntityCollisionOffset enemy(i).entity, 3, 5, 3, 0
              GXEntityApplyGravity enemy(i).entity, GX_TRUE
              enemy(i).health = 200
              enemy(i).radius = 100
              enemy(i).period = int(50*rnd)
          next
        end if
        
    elseif (tx=162 or tx=163) and ty=192 then 'igloo1
        if crate(18) then
            crate(18) = 0
            
            
          for k=0 to 2
              i=ubound(enemy)+1
                redim preserve enemy(i)
              enemy(i).typ = 2
              enemy(i).entity = GXEntityCreate("img/elf.png", 16, 16, 4)
              GXEntityPos enemy(i).entity, 2588 + int(20*k), 3084
              GXEntityCollisionOffset enemy(i).entity, 3, 5, 3, 0
              GXEntityApplyGravity enemy(i).entity, GX_TRUE
              enemy(i).health = 200
              enemy(i).radius = 100
              enemy(i).period = int(50*rnd)
          next
        end if
        
    elseif (tx=304 or tx=305) and ty=157 then 'igloo2
        if crate(19) then
            crate(19) = 0
            
          for k=0 to 3
              i=ubound(enemy)+1
                redim preserve enemy(i)
              enemy(i).typ = 2
              enemy(i).entity = GXEntityCreate("img/elf.png", 16, 16, 4)
              GXEntityPos enemy(i).entity, 4870 + int(20*k), 2525
              GXEntityCollisionOffset enemy(i).entity, 3, 5, 3, 0
              GXEntityApplyGravity enemy(i).entity, GX_TRUE
              enemy(i).health = 200
              enemy(i).radius = 100
              enemy(i).period = int(50*rnd)
          next
        end if
    

    end if



end if

End Sub

sub HandleEnemyMovement
    for i=0 to ubound(enemy)
        if pilot then
            entity = vehicle(av).entity
            
            
            if direction = MOVE_RIGHT then
                entity_x0 = 90
                entity_y0 = 30
            else
                entity_x0 = 50
                entity_y0 = 30
            
            
            end if
            
            entity_w =  GXEntityWidth(vehicle(av).entity)
            entity_h = GXEntityHeight(vehicle(av).entity)
        else
            entity = player
            
            entity_x0 = 12
            entity_y0 = 14
            
            entity_w =  GXEntityWidth(player)
            entity_h = GXEntityHeight(player)
        end if
        
    'scene box -- enemy activate
        if GXEntityVisible(enemy(i).entity) = GX_TRUE then
        if GXEntityX(enemy(i).entity) > GXSceneX then
        if GXEntityX(enemy(i).entity) < GXSceneX + GXSceneWidth then
        if GXEntityY(enemy(i).entity) > GXSceneY then
        if GXEntityY(enemy(i).entity) < GXSceneY + GXSceneHeight then
        
        'enemy follow
            if enemy(i).radius > 0 then
                vx = GXEntityVX(enemy(i).entity)
                vy = GXEntityVY(enemy(i).entity)
            
                if abs( GXEntityX(enemy(i).entity) - GXEntityX(entity) ) < enemy(i).radius then
                if abs( GXEntityX(enemy(i).entity) - GXEntityX(entity) ) > 15 then
                    'GXEntityVX enemy(1).entity, 10
                    if GXEntityX(enemy(i).entity) < GXEntityX(entity)
                        vx = vx + ACCEL*0.3
                        If vx > MAX_ACCEL*0.5 Then vx = MAX_ACCEL*0.5
                        edirection = MOVE_RIGHT
                        GXEntityAnimate enemy(i).entity, edirection, 15
                    else
                        vx = vx - ACCEL*0.3
                        If vx < MAX_ACCEL*0.5* -1 Then vx = MAX_ACCEL*0.5 * -1
                        edirection = MOVE_LEFT
                        GXEntityAnimate enemy(i).entity, edirection, 15
                    end if
                    
                else
                    vx = 0
                    vy = 0
                    if GXEntityX(enemy(i).entity) < GXEntityX(entity)
                        edirection = MOVE_RIGHT
                    else
                        edirection = MOVE_LEFT
                    end if
                    GXEntityFrameSet enemy(i).entity, edirection, 1
                    GXEntityAnimateStop enemy(i).entity
                end if
                end if
                
                GXEntityVX enemy(i).entity, vx
                GXEntityVY enemy(i).entity, vy
            
            else
            
                if GXEntityX(enemy(i).entity) < GXEntityX(entity)
                    edirection = MOVE_RIGHT
                    GXEntityFrameSet enemy(i).entity, edirection, 1
                    GXEntityAnimateStop enemy(i).entity
                else
                    edirection = MOVE_LEFT
                    GXEntityFrameSet enemy(i).entity, edirection, 1
                    GXEntityAnimateStop enemy(i).entity

                end if
                
            end if
            
        '''''''enemy fire
            if enemy(i).period = 0 and (enemy(i).typ = 1 or enemy(i).typ=2) then

                enemy(i).period = 50
                select case enemy(i).typ
                case 1
                    enemy(i).period = int(weapon(1).period*2.5*rnd)
                   x = 12 + GXEntityX(enemy(i).entity) '- GXSceneX
                   y = 14 + GXEntityY(enemy(i).entity) '- GXSceneY

                case 2
                    enemy(i).period = int(weapon(1).period*2.5*rnd)
                   x = 8 + GXEntityX(enemy(i).entity) '- GXSceneX
                   y = 9 + GXEntityY(enemy(i).entity) '- GXSceneY

                end select


                x0 = entity_x0 + GXEntityX(entity) '- GXSceneX
                y0 = entity_y0 + GXEntityY(entity) '- GXSceneY

                a = atan2(y0 - y, x0 - x)

                lx = x - GXSceneX
                ly = y - GXSceneY

                ''''gun fire collisions
                range = 200
                select case enemy(i).typ
                case 1
                   range = weapon(1).range*1.0
                case 2
                   range = weapon(1).range*1.0
                case else
                   range = 10'weapon(0).range
                end select
                
                for t=0 to range step 1
                    x = x + cos(a)
                    y = y + sin(a)

                    tx = Fix((x)/GXTilesetWidth)
                    ty = Fix((y)/GXTilesetHeight)
                    tile = GXMapTile(tx, ty, COLLISION_LAYER) 'layer=1

                    if tile <> 0 then exit for

                    enemy_hit = 0

                    px = GXEntityX(entity)
                    py = GXEntityY(entity)
                    if x > px and x < px + entity_w then
                    if y > py and y < py + entity_h then
                        enemy_hit = 1
                    end if
                    end if

                    if enemy_hit then exit for
                next

                line -(x - GXSceneX, y - GXSceneY), rgb(255,0,0)
                lx1 = x - GXSceneX
                ly1 = y - GXSceneY

                if enemy_hit = 1 then
                   'make smoke particles
                   if esmoke_t = 0 then
                       esmoke_t = 50

                       x =  9 + GXEntityX(enemy(i).entity) '- GXSceneX
                       y = 13 + GXEntityY(enemy(i).entity) '- GXSceneY

                       x0 = entity_x0 + GXEntityX(entity) '- GXSceneX
                       y0 = entity_y0 + GXEntityY(entity) '- GXSceneY
                       'line (x0, y0)-(px, py), rgb(255,0,0)


                       a = atan2(y0 - y, x0 - x)

                   ''recoil
                       'GXEntityVX player, -weapon(aw).recoil*cos(a)
                       'GXEntityVY player, -weapon(aw).recoil*sin(a)

                   'make gunfire particles
                       select case enemy(i).typ
                       case 2
                         esmoke_t = 8
                         for j=0 to ubound(esmoke)
                             esmoke(j).x = x + 55*cos(a - 0.5*rnd)
                             esmoke(j).y = y + 55*sin(a - 0.5*rnd)
                             esmoke(j).vx = cos(a)
                             esmoke(j).vy = sin(a)

                         next
                       case 1 'machinegun
                          esmoke_t = 8
                          for j=0 to ubound(esmoke)
                              esmoke(j).x = x + 35*cos(a - 0.5*rnd)
                              esmoke(j).y = y + 35*sin(a - 0.5*rnd + 0.35) 
                              esmoke(j).vx = cos(a)
                              esmoke(j).vy = sin(a)

                          next
                       end select

                   'make blood particles
                       eblood_t = 10
                       for j=0 to ubound(eblood)
                           eblood(j).x = x0
                           eblood(j).y = y0
                           eblood(j).vx = 5*cos(a + rnd)
                           eblood(j).vy = 5*(rnd - 0.5)*sin(a + rnd)
                       next

                   end if
                   
                   'if (pilot=0) or ((pilot=1) and (av=0 or av=1 or av=2)) then

                        armor = 1.0
                        select case enemy(i).typ
                        case 1
                            health = int(health - armor*weapon(1).damage*0.25)
                        case 2
                            health = int(health - armor*weapon(1).damage*0.15)
                        case else
                            health = int(health - armor*weapon(0).damage*0.1)
                        end select
                    'end if
                end if
            else
                enemy(i).period = enemy(i).period - 1
            end if

        end if
        end if
        end if
        end if
        end if
    next   

end sub



'''''''''''''''''''''''''''''
''''''''''''redraw'''''''''''
'''''''''''''''''''''''''''''

Sub OnDrawScreen (e As GXEvent)




    
    '''''''''''draw gun    
    if GXEntityVisible(player) = GX_TRUE then
        select case aw
        case 0 'sword
            
            if direction = MOVE_RIGHT then
                x0 = 16 + GXEntityX(player) - GXSceneX
                y0 = 14 + GXEntityY(player) - GXSceneY
                a = atan2( mousey - y0, mousex - x0 )

                'if a < pi/2 and a > -pi/2 then
                G2D.RotoZoom x0, y0+1, weapon(0).img, 0.3, 0.3, (a)*180/pi
            
            
            elseif direction = MOVE_LEFT then
                x0 = GXEntityWidth(player) - 17 + GXEntityX(player) - GXSceneX
                y0 = 14 + GXEntityY(player) - GXSceneY
                a = atan2( mousey - y0, mousex - x0 )
            
                G2D.RotoZoom x0, y0+1, weapon(0).img, 0.3,-0.3, (a)*180/pi
            
            end if
            
        case 1 'machine gun 
            x0 = 12 + GXEntityX(player) - GXSceneX
            y0 = 14 + GXEntityY(player) - GXSceneY
            a = atan2( mousey - y0, mousex - x0 )
        
        
        
            if a < pi/2 and a > -pi/2 then
                G2D.RotoZoom x0, y0+1, weapon(1).img, 0.35, 0.35, (a)*180/pi
            else
                G2D.RotoZoom x0, y0+1, weapon(1).img, 0.35,-0.35, (a)*180/pi
            end if
            
        case 2 'laser
            x0 = 12 + GXEntityX(player) - GXSceneX
            y0 = 14 + GXEntityY(player) - GXSceneY
            a = atan2( mousey - y0, mousex - x0 )
            
            
            if a < pi/2 and a > -pi/2 then
                G2D.RotoZoom x0, y0+1, weapon(2).img, 0.5, 0.5, (a)*180/pi
            else
                G2D.RotoZoom x0, y0+1, weapon(2).img, 0.5,-0.5, (a)*180/pi
            end if
        
        end select

        'line (x0, y0)-step(x, y), rgb(255,255,0)
    end if
    
    'draw enemy guns
    for i=0 to ubound(enemy)
    if enemy(i).typ <> 3 and enemy(i).typ <> 4 then
       if GXEntityVisible(enemy(i).entity) = GX_TRUE then
       if GXEntityX(enemy(i).entity) > GXSceneX then
       if GXEntityX(enemy(i).entity) < GXSceneX + GXSceneWidth then
       if GXEntityY(enemy(i).entity) > GXSceneY then
       if GXEntityY(enemy(i).entity) < GXSceneY + GXSceneHeight then

           if pilot then
               entity = vehicle(av).entity

                if direction=MOVE_RIGHT then
                   entity_x0 = 90
                   entity_y0 = 30
                else
                   entity_x0 = 50
                   entity_y0 = 30
                
                end if
           else
               entity = player

               entity_x0 = 12
               entity_y0 = 12
           end if

           'if edirection = MOVE_RIGHT then
           '    x0 = 16 + GXEntityX(player) - GXSceneX
           '    y0 = 14 + GXEntityY(player) - GXSceneY
           '
           'elseif direction = MOVE_LEFT then
           '    x0 = GXEntityWidth(player) - 17 + GXEntityX(player) - GXSceneX
           '    y0 = 14 + GXEntityY(player) - GXSceneY
           
           
           if enemy(i).typ = 2 then
               x0 = 8 + GXEntityX(enemy(i).entity) - GXSceneX
               y0 = 9 + GXEntityY(enemy(i).entity) - GXSceneY
           
           else
           
           
               x0 = 12 + GXEntityX(enemy(i).entity) - GXSceneX
               y0 = 14 + GXEntityY(enemy(i).entity) - GXSceneY
           end if


           px = entity_x0 + GXEntityX(entity) - GXSceneX
           py = entity_y0 + GXEntityY(entity) - GXSceneY

           a2 = atan2(py - y0, px - x0)

           timg = weapon(1).img
           select case enemy(i).typ
           case 1
               timg = weapon(1).img
               z = 0.35
           case 2
               timg = weapon(1).img
               z = 0.25
           end select
           
           
           
           
           if abs(a2) < pi/2 then
               G2D.RotoZoom x0, y0+1, timg, z, z, a2*180/pi
           else
               G2D.RotoZoom x0, y0+1, timg, z,-z, a2*180/pi
           end if

       end if
       end if
       end if
       end if
       end if

    end if
    next
    
    
    
''''''''''''''''''''''''
'''laser reflections''''
''''''''''''''''''''''''
    if laser = 1 then
           x0 = 12 + GXEntityX(player) - GXSceneX
           y0 = 14 + GXEntityY(player) - GXSceneY

           a = atan2( mousey - y0, mousex - x0 )
            
          preset(x0 + 17*cos(a), y0 + 17*sin(a))

          '''laser collisions
          x = 12 + 20*cos(a) + GXEntityX(player)
          y = 14 + 20*sin(a) + GXEntityY(player)
          
          tx = fix((x)/GXTileSetWidth)
          ty = fix((y)/GXTileSetHeight)
          tile = GXMapTile(tx, ty, COLLISION_LAYER) 'layer=1
          tile2 = GXMapTile(tx, ty, 2) 'layer=2
          
          
          
          if tile = 0 then
          

              cs = cos(a)
              sn = sin(a)

              tile_in = 0

              for t=0 to weapon(aw).range step 1

                  tx = fix((x)/GXTilesetWidth)
                  ty = fix((y)/GXTilesetHeight)
                  tile = GXMapTile(tx, ty, collision_layer) 'layer=1


                  'dim tpos as GXPosition
                  'GXMapTilePosAt x, y, tpos

                  if tile_in = 1 then
                      if tile = 0 then tile_in = 0
                  end if

                  if tile <> 0 and tile_in = 0 then
                      if tile = 101 or tile = 42 then exit for 'dirt
'''''button          
          if tile = 165 then
          
              if tx=7  and ty=164  then
                  if box(0) then
                      GXMapTile tx, ty, 1, 206
                  end if
              elseif tx=72  and ty=197  then
                  if box(1) then '''stairs
                      GXMapTile tx, ty, 1, 206
                      
                      GXMapTile 75, 195, 1, 206
                      GXMapTile 75, 196, 1, 206
                      GXMapTile 76, 196, 1, 206
                      
                      box(1) = 0
                  end if
              elseif tx=84  and ty=196  then
                  if box(2) then '''nothing
                      GXMapTile tx, ty, 1, 206
                  end if
              elseif tx=148  and ty=201  then
                  if box(3) then 'rice 
                      'GXMapTile tx, ty, 1, 206
                      
                      GXEntityPos player, 2369, 3055
                      
                      
                  end if
              elseif tx=152  and ty=197  then
                  if box(4) then 'igloo
                      GXMapTile tx, ty, 1, 206
                      
                      
                      GXMapTile 159, 193, 1, 206
                      GXMapTile 160, 192, 1, 206
                      GXMapTile 161, 191, 1, 206
                      GXMapTile 162, 190, 1, 206
                      
                      box(4) = 0
                  end if
              elseif tx=216  and ty=193  then
                  if box(5) then 'heli1
                      GXMapTile tx, ty, 1, 206
                      
                      
                      GXMapTile 215, 216, 1, 0
                      GXMapTile 216, 216, 1, 0
                      GXMapTile 217, 216, 1, 0
                      GXMapTile 218, 216, 1, 0
                      GXMapTile 219, 216, 1, 0
                      GXMapTile 220, 216, 1, 0
                      
                      GXMapTile 221, 216, 1, 0
                      GXMapTile 222, 216, 1, 0
                      GXMapTile 223, 216, 1, 0
                      GXMapTile 224, 216, 1, 0
                      GXMapTile 225, 216, 1, 0
                      
                      box(5) = 0
                      box(6) = 0
                  end if
              elseif tx=219  and ty=216  then
                  if box(6) then 'heli2
                      GXMapTile tx, ty, 1, 206
                      
                      GXMapTile 215, 216, 1, 0
                      GXMapTile 216, 216, 1, 0
                      GXMapTile 217, 216, 1, 0
                      GXMapTile 218, 216, 1, 0
                      GXMapTile 219, 216, 1, 0
                      GXMapTile 220, 216, 1, 0
                      
                      GXMapTile 221, 216, 1, 0
                      GXMapTile 222, 216, 1, 0
                      GXMapTile 223, 216, 1, 0
                      GXMapTile 224, 216, 1, 0
                      GXMapTile 225, 216, 1, 0
                      
                      box(5) = 0
                      box(6) = 0
                  end if
              elseif tx=398  and ty=184  then
                  if box(7) then 'tower2
                      GXMapTile tx, ty, 1, 206
                      
                      
                      dim txx, tyy
                      
                      'open ladder
                      for txx = 401 to 559
                          GXMapTile txx, 161, 3, 5
                          GXMapTile txx, 162, 4, 16
                      next
                      
                      
                      'open hatch
                      for tyy = 184 to 186
                      for txx = 529 to 534
                          GXMapTile txx, tyy, 3, 0
                      next
                      next
                      
                      
                      'clear way
                      for txx = 529 to 534
                          GXMapTile txx, 184, 4, 0
                      next
                      
                      
                      
                      global_msg = "Castle unlocked"
                      
                      
                      
                      box(7) = 0
                  end if
              elseif tx=459  and ty=217  then
                  if box(8) then 'castle1
                      GXMapTile tx, ty, 1, 206
                      
                      box(8) = 0
                  end if
                  
                  
                  
              elseif tx=529  and ty=219  then
                  if box(9) then 'big ladder
                      GXMapTile tx, ty, 1, 206
                      
                      '''big ladder
                      for k=0 to 25
                          GXMapTile 592+k, 202-k, 3, 5
                          GXMapTile 592+k, 203-k, 4, 16
                      next
                      
                      
                      global_msg = "Ladder lowered"
                      
                      box(9) = 0
                  end if
                  
              elseif tx=645  and ty=160  then
                  if box(10) then 'chandalere
                      GXMapTile tx, ty, 1, 206
                      
                      box(10) = 0
                  end if
                  
                  
           '''death ray
              elseif tx=637  and ty=127  then
                  if box(11) then 'death1
                      GXMapTile tx, ty, 1, 206
                      
                      box(11) = 0
                      
                      
                      if box(11)=0 and box(12)=0 then
                          global_msg = "Victory"
                      end if
                      
                  end if
              elseif tx=653  and ty=127  then
                  if box(12) then 'death2
                      GXMapTile tx, ty, 1, 206
                      
                      
                      box(12) = 0
                      
                      if box(11)=0 and box(12)=0 then
                          global_msg = "Victory"
                      end if
                  end if
              end if
           end if
                  
                      tile_in = 1

                      xx = 16*int((x)/16)
                      yy = 16*int((y)/16)


                      if  x < -(y-yy)+xx+16  then

                          'line (xx - GXSceneX, yy - GXSceneY)-step(16,16),rgb(0,255,0),b

                          if x <= (y-yy)+xx and x >= -(y-yy)+xx   then
                              cs = -cs 
                              'line (xx - GXSceneX, yy - GXSceneY)-step(0,16),rgb(0,0,255)
                          else
                              sn = -sn
                              'line (xx - GXSceneX, yy - GXSceneY)-step(16,0),rgb(0,0,255)
                          end if

                      else
                          if y > -(x-xx)+yy and y < (x-xx)+yy then
                              cs = -cs 
                              'line (xx - GXSceneX + 16, yy - GXSceneY)-step(0,16),rgb(0,0,255)
                          else
                              sn = -sn
                              'line (xx - GXSceneX, yy - GXSceneY + 16)-step(16,0),rgb(0,0,255)

                          end if

                      'else
                      '    exit for

                      end if

                      preset (x - GXSceneX, y - GXSceneY)

                  else
      'cylinders

                      for i=0 to ubound(reflector)
                          rx = reflector(i).x
                          ry = reflector(i).y

                          r = reflector(i).r


                          dx = x - rx
                          dy = y - ry

                          if dx*dx + dy*dy < r*r then
                              aa = atan2(dy, dx)
                              a = 2*aa - a - pi

                              cs = cos(a)
                              sn = sin(a)

                              exit for
                          end if
                      next
                  end if

                  x = x + cs
                  y = y + sn
                  line -(x - GXSceneX, y - GXSceneY), rgb(255,0,0)
                  
                  G2D.FillCircle x-GXSceneX, y-GXSceneY, 18, rgba(255,0,100,2)
              next

          
          end if

    end if

    
    if shot_time > 0 then
       shot_time = shot_time - 1

       x0 = 12 + GXEntityX(player) - GXSceneX
       y0 = 14 + GXEntityY(player) - GXSceneY
       
       a = atan2( mousey - y0, mousex - x0 )

    'hits
       if hit >= 0 then

           G2D.FillCircle hit_x - GXSceneX, hit_y - GXSceneY,3,rgb(255,0,0)

'enemy(hit).health = enemy(hit).health - weapon(aw).damage
           hit = -1

       'make blood particles
           blood_t = 10

           for i=0 to ubound(blood)
               blood(i).x = hit_x
               blood(i).y = hit_y

               blood(i).vx = 5*cos(a + rnd)
               blood(i).vy = 5*(rnd - 0.5)*sin(a + rnd)

           next

       end if
       
       
       '''''''''''''
       cr = rgba(155, 155, 0, 255*shot_time/(weapon(aw).period))
   
       if (GXEntityVisible(player) = GX_TRUE) then

          if aw = 0 then
            if direction = MOVE_RIGHT then
                x0 = 12 + GXEntityX(player) - GXSceneX
                y0 = 14 + GXEntityY(player) - GXSceneY
                a = atan2( mousey - y0, mousex - x0 )
                G2D.FillCircle x0 + weapon(0).range*cos(a - 0.2), y0 + weapon(0).range*sin(a - 0.2), 3, cr'rgba(255,0,0,255)
            else
                'x0 = GXEntityWidth(player) - 41 + GXEntityX(player) - GXSceneX
                'y0 = 17 + GXEntityY(player) - GXSceneY
                x0 = 12 + GXEntityX(player) - GXSceneX
                y0 = 14 + GXEntityY(player) - GXSceneY
                a = atan2( mousey - y0, mousex - x0 )
                G2D.FillCircle x0 + weapon(0).range*cos(a + 0.2), y0 + weapon(0).range*sin(a + 0.2), 3, cr'rgba(255,0,0,255)
            end if

          else 'if aw <> 3 then
               x0 = 12 + GXEntityX(player) - GXSceneX
               y0 = 14 + GXEntityY(player) - GXSceneY

               a = atan2( mousey - y0, mousex - x0 )

              G2D.LineWidth 1
              select case aw 
              case 1
                  preset(x0 + 32*cos(a), y0 + 32*sin(a))
              case 2
                  preset(x0 + 17*cos(a), y0 + 17*sin(a))
              end select

              '''gun fire collisions
              x = 12 + GXEntityX(player)
              y = 14 + GXEntityY(player)
              for t=0 to weapon(aw).range step 1
                  x = x + cos(a)
                  y = y + sin(a)

                  tx = Fix((x)/GXTilesetWidth)
                  ty = Fix((y)/GXTilesetHeight)
                  tile = GXMapTile(tx, ty, COLLISION_LAYER) 'layer=1

                  if tile <> 0 then exit for
              next

              line -(x - GXSceneX, y - GXSceneY), cr'rgb(255,0,0)
              
              
                for t=0 to 50 
                      x = x0 + (32 + t)*cos(a)
                      y = y0 + (32 + t)*sin(a)

                    G2D.FillCircle x , y , 20+t/5, rgba(255,255,0,2-t/50)

                next

          end if

       end if
       shot = 0
    end if

    
    
    G2D.LineWidth 1
    if lx>=0 then
        line (lx, ly)-(lx1, ly1), rgba(155,155,0,100)
        lx=-1
    end if
    

'''''''''''''''
''''''text'''''
'''''''''''''''

    x = mousex + GXSceneX
    y = mousey + GXSceneY
    tx = Fix(x/GXTilesetWidth)
    ty = Fix(y/GXTilesetHeight)
    tile = GXMapTile(tx, ty, COLLISION_LAYER) 'layer=1
    px = Fix(GXEntityX(player)/GXTilesetWidth)
    py = Fix(GXEntityY(player)/GXTilesetHeight)
    
    
    
    GXDrawText GXFONT_DEFAULT, 3,  7, "+"+str(health)
    GXDrawText GXFONT_DEFAULT, 3,  21, "L"+str(checkpoint)
    
    GXDrawText GXFONT_DEFAULT, 70, 7, global_msg

    
    if pilot then
        GXDrawText GXFONT_DEFAULT, 3, GXSceneHeight - 20, str(int(GXEntityX(vehicle(av).entity)))+" "+str(int(GXEntityY(vehicle(av).entity)))
    else
        '''mainline
        'GXDrawText GXFONT_DEFAULT, 3, GXSceneHeight - 20, str(int(GXEntityX(player)))+" "+str(int(GXEntityY(player)))+" "+str(px)+" "+str(py)
        
        'GXDrawText GXFONT_DEFAULT, 3, GXSceneHeight - 20, "mouse at " + str(int(x))+" "+str(int(y))+", player at tile "+str(px)+" "+str(py)
        'GXDrawText GXFONT_DEFAULT, 3, GXSceneHeight - 30, "mouse at tile " + str(tx)+" "+str(ty)+" "+str(tile)
    end if

    
    
    
    'deaths
    for i=0 to ubound(enemy)
    if enemy(i).health <= 0 then
    if GXEntityVisible(enemy(i).entity) then
    
        GXEntityPos enemy(i).entity, GXEntityX(enemy(i).entity), 100000'GXEntityY(enemy(i).entity) + 32

        'dead
        GXEntityVisible enemy(i).entity, GX_FALSE
        
    end if
    end if
    next
    
    

    
'particles
    if GXEntityVisible(player) = GX_TRUE then
        if blood_t > 0 then
            blood_t = blood_t - 1

            for i=0 to ubound(blood)
                blood(i).x = blood(i).x + blood(i).vx
                blood(i).y = blood(i).y + blood(i).vy 
                G2D.FillCircle blood(i).x - GXSceneX, blood(i).y - GXSceneY,1, rgba(255,0,0,180)
            next

        end if
        if smoke_t > 0 then
            smoke_t = smoke_t - 1

            for i=0 to ubound(smoke)
                smoke(i).x = smoke(i).x + smoke(i).vx
                smoke(i).y = smoke(i).y + smoke(i).vy 
                G2D.FillCircle smoke(i).x - GXSceneX, smoke(i).y - GXSceneY,1, rgba(100,100,100,180)
            next

        end if
        if eblood_t > 0 then
            eblood_t = eblood_t - 1

            for i=0 to ubound(eblood)
                eblood(i).x = eblood(i).x + eblood(i).vx
                eblood(i).y = eblood(i).y + eblood(i).vy 
                G2D.FillCircle eblood(i).x - GXSceneX, eblood(i).y - GXSceneY,1, rgba(255,0,0,180)
            next

        end if
    end if
        
    'no blood in helicopter
    if esmoke_t > 0 then
        esmoke_t = esmoke_t - 1

        for i=0 to ubound(esmoke)
            esmoke(i).x = esmoke(i).x + esmoke(i).vx
            esmoke(i).y = esmoke(i).y + esmoke(i).vy 

            G2D.FillCircle esmoke(i).x - GXSceneX, esmoke(i).y - GXSceneY,1, rgba(100,100,100,180)
        next
    end if
    
    
    
    'for i=0 to ubound(reflector)
    '
    '
    '    x = reflector(i).x - GXSceneX 'GXEntityX(reflector(i).entity) - GXSceneX
    '    y = reflector(i).y - GXSceneY 'GXEntityY(reflector(i).entity) - GXSceneY
    '    r = reflector(i).r
    '    
    '    
    '    circle (x, y), r, rgb(255,0,0)
    '    'G2D.FillCircle(x, y),r,rgb(255,0,0)
    '
    'next


'game over
    If gameOver Then
        Dim As Integer x, y
        x = GXSceneWidth / 2 - 32
        y = GXSceneHeight / 2 - 8
        GXDrawText GXFONT_DEFAULT_BLACK, x+1, y+1, "GAME OVER"
        GXDrawText GXFONT_DEFAULT, x, y, "GAME OVER"
    End If
End Sub


sub LoadMirrors
  'i=0
  'reflector(i).entity = GXEntityCreate("img/ice2.png", 75, 74, 1)
  'GXEntityPos reflector(i).entity, 2140, 3140
  'GXEntityApplyGravity reflector(i).entity, GX_FALSE
  'reflector(i).x = GXEntityX(reflector(i).entity) + GXEntityWidth(reflector(i).entity)/2
  'reflector(i).y = GXEntityY(reflector(i).entity) + GXEntityHeight(reflector(i).entity)/2
  'reflector(i).r = 37
  'i=i+1
  'reflector(i).entity = GXEntityCreate("img/ice2.png", 75, 74, 1)
  'GXEntityPos reflector(i).entity, 2230, 3140
  'GXEntityApplyGravity reflector(i).entity, GX_FALSE
  'reflector(i).x = GXEntityX(reflector(i).entity) + GXEntityWidth(reflector(i).entity)/2
  'reflector(i).y = GXEntityY(reflector(i).entity) + GXEntityHeight(reflector(i).entity)/2
  'reflector(i).r = 37
  'i=i+1
  'reflector(i).entity = GXEntityCreate("img/ice2.png", 75, 74, 1)
  'GXEntityPos reflector(i).entity, 2185, 3220
  'GXEntityApplyGravity reflector(i).entity, GX_FALSE
  'reflector(i).x = GXEntityX(reflector(i).entity) + GXEntityWidth(reflector(i).entity)/2
  'reflector(i).y = GXEntityY(reflector(i).entity) + GXEntityHeight(reflector(i).entity)/2
  'reflector(i).r = 37



   'i=i+1
   'reflector(i).entity = GXEntityCreate("img/ice2.png", 75, 74, 1)
   'GXEntityPos reflector(i).entity, 1710, 2800
   'GXEntityApplyGravity reflector(i).entity, GX_FALSE
   'reflector(i).x = GXEntityX(reflector(i).entity) + int(GXEntityWidth(reflector(i).entity)/2)
   'reflector(i).y = GXEntityY(reflector(i).entity) + int(GXEntityHeight(reflector(i).entity)/2)
   'reflector(i).r = 37
   'i=i+1
   'reflector(i).entity = GXEntityCreate("img/ice2.png", 75, 74, 1)
   'GXEntityPos reflector(i).entity, 1800, 2800
   'GXEntityApplyGravity reflector(i).entity, GX_FALSE
   'reflector(i).x = GXEntityX(reflector(i).entity) + int(GXEntityWidth(reflector(i).entity)/2)
   'reflector(i).y = GXEntityY(reflector(i).entity) + int(GXEntityHeight(reflector(i).entity)/2)
   'reflector(i).r = 37
   'i=i+1
   'reflector(i).entity = GXEntityCreate("img/ice2.png", 75, 74, 1)
   'GXEntityPos reflector(i).entity, 1750, 2880
   'GXEntityApplyGravity reflector(i).entity, GX_FALSE
   'reflector(i).x = GXEntityX(reflector(i).entity) + int(GXEntityWidth(reflector(i).entity)/2)
   'reflector(i).y = GXEntityY(reflector(i).entity) + int(GXEntityHeight(reflector(i).entity)/2)
   'reflector(i).r = 37




    dim a, i
    i = -1


    x0 = 450
    y0 = 2900
    rr = 50
    r0 = 37
    a0 = pi/3
    for a = 0 to 2*pi step 2*pi/3
        
        xx = x0 + rr*cos(a + a0)
        yy = y0 + rr*sin(a + a0)
        
        i=i+1
        reflector(i).entity = GXEntityCreate("img/ice2.png", 75, 74, 1)
        GXEntityPos reflector(i).entity, int(xx-r0/2), int(yy-r0/2)
        GXEntityApplyGravity reflector(i).entity, GX_FALSE
        reflector(i).x = GXEntityX(reflector(i).entity) + r0
        reflector(i).y = GXEntityY(reflector(i).entity) + r0
        reflector(i).r = r0
    next


    x0 = 1800
    y0 = 2880
    rr = 55
    r0 = 37
    a0 = pi/3 + 0.3
    for a = 0 to 2*pi step 2*pi/3
        
        xx = x0 + rr*cos(a + a0)
        yy = y0 + rr*sin(a + a0)
        
        i=i+1
        reflector(i).entity = GXEntityCreate("img/ice2.png", 75, 74, 1)
        GXEntityPos reflector(i).entity, int(xx-r0/2), int(yy-r0/2)
        GXEntityApplyGravity reflector(i).entity, GX_FALSE
        reflector(i).x = GXEntityX(reflector(i).entity) + r0
        reflector(i).y = GXEntityY(reflector(i).entity) + r0
        reflector(i).r = r0
    next


    x0 = 2222
    y0 = 3210
    rr = 25
    r0 = 15
    a0 = pi
    for a = 0 to 2*pi step 2*pi/3
        
        xx = x0 + rr*cos(a + a0)
        yy = y0 + rr*sin(a + a0)
        
        i=i+1
        reflector(i).entity = GXEntityCreate("img/ice4.png", 75, 74, 1)
        GXEntityPos reflector(i).entity, int(xx-r0/2), int(yy-r0/2)
        GXEntityApplyGravity reflector(i).entity, GX_FALSE
        reflector(i).x = GXEntityX(reflector(i).entity) + r0
        reflector(i).y = GXEntityY(reflector(i).entity) + r0
        reflector(i).r = r0
    next
    
    
    
    
    x0 = 1507
    y0 = 3990
    r0 = 15
    for j = 0 to 24
    
        i=i+1
        reflector(i).entity = GXEntityCreate("img/ice4.png", 75, 74, 1)
        GXEntityPos reflector(i).entity, int(x0 - r0 + 80*j), int(y0 - r0)
        GXEntityApplyGravity reflector(i).entity, GX_FALSE
        reflector(i).x = GXEntityX(reflector(i).entity) + r0
        reflector(i).y = GXEntityY(reflector(i).entity) + r0
        reflector(i).r = r0
    
    next

    x0 = 8570
    y0 = 3493
    rr = 80
    r0 = 51
    a0 = 0'pi/3 + 0.3
    for a = 0 to 2*pi step 2*pi/3
        
        xx = x0 + rr*cos(a + a0)
        yy = y0 + rr*sin(a + a0)
        
        i=i+1
        reflector(i).entity = GXEntityCreate("img/ice3.png", 101, 102, 1)
        GXEntityPos reflector(i).entity, int(xx-r0/2), int(yy-r0/2)
        GXEntityApplyGravity reflector(i).entity, GX_FALSE
        reflector(i).x = GXEntityX(reflector(i).entity) + r0
        reflector(i).y = GXEntityY(reflector(i).entity) + r0
        reflector(i).r = r0
    next


    x0 = 10305
    y0 = 2542
    rr = 77
    r0 = 51
    a0 = 0'pi/3 + 0.3
    for a = 0 to 2*pi step 2*pi/4
        
        xx = x0 + rr*cos(a + a0)
        yy = y0 + rr*sin(a + a0)
        
        i=i+1
        reflector(i).entity = GXEntityCreate("img/ice3.png", 101, 102, 1)
        GXEntityPos reflector(i).entity, int(xx-r0/2), int(yy-r0/2)
        GXEntityApplyGravity reflector(i).entity, GX_FALSE
        reflector(i).x = GXEntityX(reflector(i).entity) + r0
        reflector(i).y = GXEntityY(reflector(i).entity) + r0
        reflector(i).r = r0
    next

    redim preserve reflector(i)



end sub

sub LoadEnemies
       'steve house
       i=0
       enemy(i).typ = 1
       enemy(i).entity = GXEntityCreate("img/cory.png", 24, 24, 4)
       GXEntityPos enemy(i).entity, 9696, 2121
       GXEntityCollisionOffset enemy(i).entity, 3, 5, 3, 0
       GXEntityApplyGravity enemy(i).entity, GX_TRUE
       enemy(i).health = 1000
       enemy(i).radius = 0
       enemy(i).period = int(50*rnd)
       
       i=i+1
       enemy(i).typ = 2
       enemy(i).entity = GXEntityCreate("img/elf.png", 16, 16, 4)
       GXEntityPos enemy(i).entity, 10232, 927
       GXEntityCollisionOffset enemy(i).entity, 3, 5, 3, 0
       GXEntityApplyGravity enemy(i).entity, GX_TRUE
       enemy(i).health = 200
       enemy(i).radius = 0
       enemy(i).period = int(50*rnd)

       i=i+1
       enemy(i).typ = 2
       enemy(i).entity = GXEntityCreate("img/elf.png", 16, 16, 4)
       GXEntityPos enemy(i).entity, 10201, 1009
       GXEntityCollisionOffset enemy(i).entity, 3, 5, 3, 0
       GXEntityApplyGravity enemy(i).entity, GX_TRUE
       enemy(i).health = 200
       enemy(i).radius = 0
       enemy(i).period = int(50*rnd)


       i=i+1
       enemy(i).typ = 2
       enemy(i).entity = GXEntityCreate("img/elf.png", 16, 16, 4)
       GXEntityPos enemy(i).entity, 10425, 928
       GXEntityCollisionOffset enemy(i).entity, 3, 5, 3, 0
       GXEntityApplyGravity enemy(i).entity, GX_TRUE
       enemy(i).health = 200
       enemy(i).radius = 0
       enemy(i).period = int(50*rnd)


       i=i+1
       enemy(i).typ = 2
       enemy(i).entity = GXEntityCreate("img/elf.png", 16, 16, 4)
       GXEntityPos enemy(i).entity, 10455, 1006
       GXEntityCollisionOffset enemy(i).entity, 3, 5, 3, 0
       GXEntityApplyGravity enemy(i).entity, GX_TRUE
       enemy(i).health = 200
       enemy(i).radius = 0
       enemy(i).period = int(50*rnd)


       i=i+1
       enemy(i).typ = 2
       enemy(i).entity = GXEntityCreate("img/elf.png", 16, 16, 4)
       GXEntityPos enemy(i).entity, 10200, 1216
       GXEntityCollisionOffset enemy(i).entity, 3, 5, 3, 0
       GXEntityApplyGravity enemy(i).entity, GX_TRUE
       enemy(i).health = 200
       enemy(i).radius = 0
       enemy(i).period = int(50*rnd)


       i=i+1
       enemy(i).typ = 2
       enemy(i).entity = GXEntityCreate("img/elf.png", 16, 16, 4)
       GXEntityPos enemy(i).entity, 10454, 1216
       GXEntityCollisionOffset enemy(i).entity, 3, 5, 3, 0
       GXEntityApplyGravity enemy(i).entity, GX_TRUE
       enemy(i).health = 200
       enemy(i).radius = 0
       enemy(i).period = int(50*rnd)


       i=i+1
       enemy(i).typ = 2
       enemy(i).entity = GXEntityCreate("img/elf.png", 16, 16, 4)
       GXEntityPos enemy(i).entity, 11126, 2390
       GXEntityCollisionOffset enemy(i).entity, 3, 5, 3, 0
       GXEntityApplyGravity enemy(i).entity, GX_TRUE
       enemy(i).health = 200
       enemy(i).radius = 0
       enemy(i).period = int(50*rnd)



       i=i+1
       enemy(i).typ = 2
       enemy(i).entity = GXEntityCreate("img/elf.png", 16, 16, 4)
       GXEntityPos enemy(i).entity, 10716, 1849
       GXEntityCollisionOffset enemy(i).entity, 3, 5, 3, 0
       GXEntityApplyGravity enemy(i).entity, GX_TRUE
       enemy(i).health = 200
       enemy(i).radius = 0
       enemy(i).period = int(50*rnd)


       i=i+1
       enemy(i).typ = 2
       enemy(i).entity = GXEntityCreate("img/elf.png", 16, 16, 4)
       GXEntityPos enemy(i).entity, 10327, 650
       GXEntityCollisionOffset enemy(i).entity, 3, 5, 3, 0
       GXEntityApplyGravity enemy(i).entity, GX_TRUE
       enemy(i).health = 200
       enemy(i).radius = 0
       enemy(i).period = int(50*rnd)




       i=i+1
       enemy(i).typ = 2
       enemy(i).entity = GXEntityCreate("img/elf.png", 16, 16, 4)
       GXEntityPos enemy(i).entity, 7749, 3590
       GXEntityCollisionOffset enemy(i).entity, 3, 5, 3, 0
       GXEntityApplyGravity enemy(i).entity, GX_TRUE
       enemy(i).health = 200
       enemy(i).radius = 100
       enemy(i).period = int(50*rnd)

       i=i+1
       enemy(i).typ = 2
       enemy(i).entity = GXEntityCreate("img/elf.png", 16, 16, 4)
       GXEntityPos enemy(i).entity, 10083, 2184
       GXEntityCollisionOffset enemy(i).entity, 3, 5, 3, 0
       GXEntityApplyGravity enemy(i).entity, GX_TRUE
       enemy(i).health = 200
       enemy(i).radius = 100
       enemy(i).period = int(50*rnd)

       i=i+1
       enemy(i).typ = 2
       enemy(i).entity = GXEntityCreate("img/elf.png", 16, 16, 4)
       GXEntityPos enemy(i).entity, 10594, 2171
       GXEntityCollisionOffset enemy(i).entity, 3, 5, 3, 0
       GXEntityApplyGravity enemy(i).entity, GX_TRUE
       enemy(i).health = 200
       enemy(i).radius = 100
       enemy(i).period = int(50*rnd)



        redim preserve enemy(i)






'   for j=0 to 10
'   for j=0 to 10
'       i=i+1
'       enemy(i).typ = 1
'       enemy(i).entity = GXEntityCreate("img/cory.png", 24, 24, 4)
'       GXEntityPos enemy(i).entity, 1200 + int(1500*rnd), 3500
'       GXEntityCollisionOffset enemy(i).entity, 3, 5, 3, 0
'       GXEntityApplyGravity enemy(i).entity, GX_TRUE
'       enemy(i).health = 200
'       enemy(i).radius = 0
'       enemy(i).period = int(50*rnd)
'       i=i+1
'       enemy(i).typ = 2
'       enemy(i).entity = GXEntityCreate("img/elf.png", 16, 16, 4)
'       GXEntityPos enemy(i).entity, 1200 + int(1500*rnd), 3500
'       GXEntityCollisionOffset enemy(i).entity, 3, 5, 3, 0
'       GXEntityApplyGravity enemy(i).entity, GX_TRUE
'       enemy(i).health = 200
'       enemy(i).radius = 0
'       enemy(i).period = int(50*rnd)
'   next
'
'
'   for j=0 to 70
'       i=i+1
'       enemy(i).typ = 3
'       enemy(i).entity = GXEntityCreate("img/hogc1.png", 98, 70, 4)
'       GXEntityPos enemy(i).entity, 2700 + int(13000*rnd), 1000
'       GXEntityCollisionOffset enemy(i).entity, 20, 0, 20, 1
'       GXEntityApplyGravity enemy(i).entity, GX_TRUE
'       enemy(i).health = 300
'       enemy(i).radius = 300
'       enemy(i).period = int(50*rnd)
'   next

end sub

sub respawn
            pilot = 0
            
            GXEntityVX vehicle(av).entity, 0
            GXEntityVY vehicle(av).entity, 0
            GXEntityApplyGravity vehicle(av).entity, GX_TRUE
            
            GXEntityPos player, GXEntityX(vehicle(av).entity) , GXEntityY(vehicle(av).entity)
 
            GXSceneFollowEntity player, GXSCENE_FOLLOW_ENTITY_CENTER '_X
            GXEntityVisible player, GX_TRUE
            
        GXEntityAnimate vehicle(av).entity, direction, 15
            GXEntityAnimateStop vehicle(av).entity
            
            
            
    health = 100
    
    GXEntityVX player, 0
    GXEntityVY player, 0


    for i=0 to ubound(enemy)
        x = GXEntityX(enemy(i).entity)
        y = GXEntityY(enemy(i).entity)
        
        GXEntityPos enemy(i).entity, x, 100000
    next

    redim enemy(100)
    LoadEnemies

    select case checkpoint
    case 0
        GXEntityPos player, 303, 2980 'start
    case 1
        GXEntityPos player, 3687, 2440 'tower1
    case 2
        GXEntityPos player, 6390, 2500 'tower2
    end select
    
    box( 0) = 1
    box( 1) = 1
    box( 2) = 1
    box( 3) = 1
    box( 4) = 1
    box( 5) = 1
    box( 6) = 1
    box( 7) = 1
    box( 8) = 1
    box( 9) = 1
    box(10) = 1
    box(11) = 1
    box(12) = 1
    
  GXMapTile 653, 127, 1, 165
  GXMapTile 637, 127, 1, 165


    dim shared crate(19)
    crate( 0) = 1
    crate( 1) = 1
    crate( 2) = 1
    crate( 3) = 1
    crate( 4) = 1
    crate( 5) = 1
    crate( 6) = 1
    crate( 7) = 1
    crate( 8) = 1
    crate( 9) = 1
    crate(10) = 1
    crate(11) = 1
    crate(12) = 1
    crate(13) = 1
    crate(14) = 1
    crate(15) = 1
    crate(16) = 1
    crate(17) = 1
    crate(18) = 1
    crate(19) = 1

    global_msg = ""
end sub
