This file is included so that qbjs will save the project as a zip file.
